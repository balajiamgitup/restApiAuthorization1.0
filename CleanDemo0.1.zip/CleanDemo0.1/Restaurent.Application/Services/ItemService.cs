﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Restaurent.Domain.Entities;

namespace Restaurent.Application
{
    public class ItemService : IitemService

    {

        private readonly IitemRepository  _itemRepository;

        public ItemService(IitemRepository itemRepository)
        {
            this._itemRepository = itemRepository;
        }


     public   Task<IEnumerable<Item>> GetAllAsync()
        {
            return _itemRepository.GetAllAsync();
        }
    }
}
