﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Restaurent.Domain.Entities
{
    public class OrderItem
    {
        [Key]
        public int orderItemId { get; set; }
        public int quantity { get; set; }
        public int itemId { get; set; }
        public int orderId { get; set; }

        //  [ForeignKey("orderId")]
        //  public order order { get; set; } 
        //  public virtual Item item { get; set; }

        //   public virtual IEnumerable<bill> bill { get; set; }
    }
}
