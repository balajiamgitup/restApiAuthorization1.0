﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Restaurent.Domain.Entities
{
    public class User
    {
        public int UserId { get; set; }
        public string Name { get; set; }
        public string Password { get; set; }
        public string Email { get; set; }
        public int RoleId { get; set; }

        [ForeignKey("RoleId")]
        public virtual Role Role { get; set; }

        //   public Guid roleId { get; set; }

        // public Role roles { get; set; }

        //  [Display(Name = "Department")]
        // public virtual Guid roleId { get; set; }

        //  [ForeignKey("roleId")]
        // public virtual Role roles { get; set; }
        // public  ICollection<order> order { get; set; }

        // public ICollection<Item> item { get; set; }
        // public List<User_Role> UserRoles { get; set; }
    }
}
