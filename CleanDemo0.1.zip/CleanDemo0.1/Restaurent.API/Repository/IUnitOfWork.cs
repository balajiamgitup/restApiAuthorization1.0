﻿using Microsoft.EntityFrameworkCore;
using Restaurent.Infrastructure.Context;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Restaurent.Application.Interface
{
    public interface IUnitOfWork : IDisposable
    {


        RestDbContext Context { get; }
        Task<int> CommitAsync();

    }
}
