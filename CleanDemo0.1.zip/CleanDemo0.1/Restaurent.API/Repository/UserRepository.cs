﻿using Microsoft.EntityFrameworkCore;
using Org.BouncyCastle.Crypto.Generators;
using Restaurent.Application.Interface;
using Restaurent.Domain.Entities;
using BCrypt.Net;

namespace Restaurent.Application.Services
{
    public class UserRepository : IUserRepository
    {
        private readonly IUnitOfWork _unitOfWork;

        public UserRepository(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }

        public async Task<User> AuthenticateAsync(string username, string password)
        {
            var user = await _unitOfWork.Context.users
        .Include(x => x.Role)
        .SingleOrDefaultAsync(x => x.Name == username);

            if (user == null)
            {
                return null;
            }

            // Check if the provided password matches the hashed password in the database
            if (BCrypt.Net.BCrypt.Verify(password, user.Password))
            {
                return user;
            }

            return null;
        }
        public async Task<User> FindByNameAsync(string username)
        {
            return await _unitOfWork.Context.users
     .FirstOrDefaultAsync(u => u.Name == username);
        }



        public async Task AddAsync(User user)
        {
            await _unitOfWork.Context.users.AddAsync(user);
        }

        public async Task<User> RegisterAsync(string username, string email, string password, int RoleId)
        {
            string hashedPassword = BCrypt.Net.BCrypt.HashPassword(password);

            var user = new User
            {
                Name = username,
                Email = email,
                Password = hashedPassword,
                RoleId = RoleId
            };

            await AddAsync(user);
            await _unitOfWork.CommitAsync();

            return user;
        }
    }
}
