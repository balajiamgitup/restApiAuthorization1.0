﻿using Azure;
using Azure.Core;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using Restaurent.Application.Interface;
using Restaurent.Application.Services;
using Restaurent.Domain.Entities;
using System.IdentityModel.Tokens.Jwt;

namespace Restaurent.UI.Controllers
{
    public class AuthController : Controller
    {
    

        private readonly IUserRepository _userRepository;
        private readonly ITokenHandler _tokenHandler;

        public AuthController(IUserRepository userRepository, ITokenHandler tokenHandler)
        {
            this._userRepository = userRepository;
            this._tokenHandler = tokenHandler;
       
        }


        [HttpPost]
        [Route("login")]
        public async Task<IActionResult> LoginAsync(LoginRequest loginRequest)
        {
            var user = await _userRepository.AuthenticateAsync(loginRequest.name, loginRequest.password);

            if (user == null)
            {
                return BadRequest(new { message = "Username or password is incorrect" });
            }

            var token = await _tokenHandler.CreateTokenAsync(user);

            return Ok(new
            {
                token = token,
                Message = "Login Success!",
                RoleId = user.RoleId,


            });
        }

        [HttpPost("register")]
        public async Task<IActionResult> Register([FromBody] RegisterRequest request)
        {
            var userExists = await _userRepository.FindByNameAsync(request.Username);
            if (userExists != null)
                return StatusCode(StatusCodes.Status500InternalServerError, new { Message = "User already exists!" });

            var result = await _userRepository.RegisterAsync(request.Username, request.Email, request.Password, request.RoleId);
            var user = await _userRepository.AuthenticateAsync(request.Username, request.Password);

            if (result == null)
                return StatusCode(StatusCodes.Status500InternalServerError, new { Message = "User creation failed! Please check user details and try again." });

            return Ok(new
            {
                Id = user.UserId,
                UserName = user.Name,
                Email = user.Email,
                Password = request.Password,
                Message = "User created successfully!"
            });
        }
    }
}
    

