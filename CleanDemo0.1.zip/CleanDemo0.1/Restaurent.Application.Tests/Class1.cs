﻿namespace Restaurent.Application.Tests
{
    public class Class1
    {

    }
}